using System.Collections;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using UnityEngine;
using UnityEngine.AI;

public class Enemy : MonoBehaviour
{
    private NavMeshAgent myAgent;
    private Animator myAnimator;
    private float distance;
    private Transform target;
    void Start()
    {
        myAgent = GetComponent<NavMeshAgent>();
        myAnimator = GetComponent<Animator>();
        target = GameObject.FindGameObjectWithTag("Player").transform;
    }

    void Update()
    {
        distance = Vector3.Distance(target.position, transform.position);
        if (distance > 15)
        {
            myAgent.enabled = false;
            myAnimator.Play("Idle");
        }
        if (distance < 15 & distance > 3)
        {
            myAgent.enabled = true;
            myAgent.SetDestination(target.position);
            myAnimator.Play("Run");
        }
        if (distance <= 3)
        {
            myAgent.enabled = true;
            myAgent.SetDestination(myAgent.transform.position);
            myAgent.transform.LookAt(target.position);
            myAnimator.Play("Attack");

        }
    }
}
